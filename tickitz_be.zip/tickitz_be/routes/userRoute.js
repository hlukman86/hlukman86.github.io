const express = require("express")
const userController = require('../controller/userController')
const router = express.Router()

router.get('/', userController.getAllUser)
router.post('/', userController.addNewUser)
router.patch('/:id', userController.updateUser)
router.delete('/:id', userController.deleteUser)
router.get('/:id', userController.getUserById)




module.exports = router