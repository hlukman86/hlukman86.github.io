// model = tempat dimana kita meletakkan data yang berhubungan dengan database
const db = require('../helper/db_connection')

module.exports = {
    get: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {user_name} = req.body
        const sql = `SELECT booking.user_name, user.phone_number, user.email,booking.title, booking.date_time, booking.seats, booking.price FROM  booking inner join user on booking.user_name=user.full_name where booking.user_name like '%${user_name}%'`
        
        // const {user_name='', title=''} = req.query
        // const sql = `SELECT * FROM booking ${user_name ? `WHERE title LIKE '%${user_name}%'`: user_name && title ? `WHERE user_name LIKE '%${user_name}%' AND title LIKE '${title}%'`:''} ORDER BY date_time DESC`
        db.query(sql,(err, results)=> {
          if(err) {
            reject({message: "ada error"})
          }
          resolve({
            message: "get all from booking success",
            status: 200,
            data: results
          })
        })
      })
    },
    add: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {user_name,title, date_time, seats, price} = req.body

        db.query(`INSERT INTO booking(user_name,title, date_time, seats, price) VALUES('${user_name}', '${title}','${date_time}','${seats}','${price}')`,(err, results)=> {
          if(err) {
            console.log(err)
            reject({message: "ada error"})
          }
          resolve({
            message: "add new booking success",
            status: 200,
            data: {
              id: results.insertId,
              ...req.body,
            }
          })
        })
      })
    },
    update: (req, res) => {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM booking where id=${id}`,(err, results)=> {
          if(err) {res.send({message: "ada error"})}
      
          const previousData = {
            ...results[0],
            ...req.body
          }
          const {user_name,title, date_time, seats, price} = previousData
      
          db.query(`UPDATE booking SET user_name='${user_name}', title='${title}', date_time='${date_time}', seats='${seats}', price='${price}' WHERE id='${id}'`,(err, results)=> {
            if(err) {
              console.log(err)
              reject({message: "ada error"})
            }
            resolve({
              message: "update booking success",
              status: 200,
              data: results
            })
          })
      
        })
      })
    },
    remove:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`DELETE FROM booking where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve.send({
            message: "delete booking success",
            status: 200,
            data: results
          })
        })
      })
    },
    getById:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM booking where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve({
            message: "get by id success",
            status: 200,
            data: results
          })
        })
      })
    }
}