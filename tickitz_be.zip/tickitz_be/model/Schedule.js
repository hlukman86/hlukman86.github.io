// model = tempat dimana kita meletakkan data yang berhubungan dengan database
const db = require('../helper/db_connection')

module.exports = {
    get: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {title='', location=''} = req.query
        const sql = `SELECT * FROM schedule ${title ? `WHERE title LIKE '%${title}%'`: title && location ? `WHERE title LIKE '%${title}%' AND location LIKE '${location}%'`:''} ORDER BY premiere DESC`
        db.query(sql,(err, results)=> {
          if(err) {
            reject({message: "ada error"})
          }
          resolve({
            message: "get all from schedule success",
            status: 200,
            data: results
          })
        })
      })
    },
    add: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {title, location, price, premiere, date_star, date_end, time} = req.body

        db.query(`INSERT INTO schedule(title, location, price, premiere, date_star, date_end, time) VALUES('${title}', '${location}','${price}','${premiere}','${date_star}','${date_end}','${time}')`,(err, results)=> {
          if(err) {
            console.log(err)
            reject({message: "ada error"})
          }
          resolve({
            message: "add new schedule success",
            status: 200,
            data: {
              id: results.insertId,
              ...req.body,
            }
          })
        })
      })
    },
    update: (req, res) => {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM schedule where id=${id}`,(err, results)=> {
          if(err) {res.send({message: "ada error"})}
      
          const previousData = {
            ...results[0],
            ...req.body
          }
          const {title, location, price, premiere, date_star, date_end, time} = previousData
      
          db.query(`UPDATE schedule SET title='${title}', location='${location}', price='${price}', premiere='${premiere}', date_star='${date_star}', date_end='${date_end}', time='${time}' WHERE id='${id}'`,(err, results)=> {
            if(err) {
              console.log(err)
              reject({message: "ada error"})
            }
            resolve({
              message: "update schedule success",
              status: 200,
              data: results
            })
          })
      
        })
      })
    },
    remove:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`DELETE FROM schedule where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve.send({
            message: "delete schedule success",
            status: 200,
            data: results
          })
        })
      })
    },
    getById:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM schedule where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve({
            message: "get by id success",
            status: 200,
            data: results
          })
        })
      })
    }

}




