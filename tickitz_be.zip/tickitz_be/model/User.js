// model = tempat dimana kita meletakkan data yang berhubungan dengan database
const db = require('../helper/db_connection')

module.exports = {
    get: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {first_name='', last_name=''} = req.query
        const sql = `SELECT * FROM user ${first_name ? `WHERE first_name LIKE '%${first_name}%'`: first_name && last_name ? `WHERE first_name LIKE '%${first_name}%' AND last_name LIKE '${last_name}%'`:''} ORDER BY full_name DESC`
        db.query(sql,(err, results)=> {
          if(err) {
            reject({message: "ada error"})
          }
          resolve({
            message: "get all from user success",
            status: 200,
            data: results
          })
        })
      })
    },
    add: (req, res)=> {
      return new Promise((resolve, reject)=> {
        const {first_name, last_name, full_name, phone_number, email, password} = req.body

        db.query(`INSERT INTO user(first_name, last_name, full_name, phone_number, email, password) VALUES('${first_name}', '${last_name}','${full_name}','${phone_number}','${email}','${password}')`,(err, results)=> {
          if(err) {
            console.log(err)
            reject({message: "ada error"})
          }
          resolve({
            message: "add new user success",
            status: 200,
            data: {
              id: results.insertId,
              ...req.body,
            }
          })
        })
      })
    },
    update: (req, res) => {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM user where id=${id}`,(err, results)=> {
          if(err) {res.send({message: "ada error"})}
      
          const previousData = {
            ...results[0],
            ...req.body
          }
          const {first_name, last_name, full_name, phone_number, email, password} = previousData
      
          db.query(`UPDATE user SET first_name='${first_name}', last_name='${last_name}', full_name='${full_name}', phone_number='${phone_number}', email='${email}', password='${password}' WHERE id='${id}'`,(err, results)=> {
            if(err) {
              console.log(err)
              reject({message: "ada error"})
            }
            resolve({
              message: "update user success",
              status: 200,
              data: results
            })
          })
      
        })
      })
    },
    remove:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`DELETE FROM user where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve.send({
            message: "delete user success",
            status: 200,
            data: results
          })
        })
      })
    },
    getById:(req, res)=> {
      return new Promise((resolve, reject)=> {
        const {id} = req.params
        db.query(`SELECT * FROM user where id=${id}`,(err, results)=> {
          if(err) {reject({message: "ada error"})}
          resolve({
            message: "get by id success",
            status: 200,
            data: results
          })
        })
      })
    }
}