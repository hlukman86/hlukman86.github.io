// controller = tempat dimana kita menghubungkan antara client dan database
const User = require('../model/User')

module.exports = {
    getAllUser: async (req, res)=> {
        try {
            const results = await User.get(req, res)
            res.status(200).send(results)
        } catch (error) {
            res.status(500).send(error)
        }
    },
    addNewUser: async (req, res)=> {
        try {
            const results = await User.add(req, res)
            res.status(201).send(results)
        } catch (error) {
            res.status(400).send(error)
        }
    },
    updateUser: async (req, res) => {
        try {
            const results = await User.update(req, res)
            res.status(201).send(results)
        } catch (error) {
            res.status(400).send(error)
        }
    },
    deleteUser: async(req, res)=> {
        try {
            const results = await User.remove(req, res)
            res.status(201).send(results)
        } catch (error) {
            res.status(400).send(error)
        }
    },
    getUserById: async(req, res)=> {
        try {
            const results = await User.getById(req, res)
            res.status(200).send(results)
        } catch (error) {
            res.status(400).send(error)
        }
    }
}