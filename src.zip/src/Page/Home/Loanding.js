function Loading() {
    return <h1 className="font-d-s">loading...</h1>
}

export default Loading