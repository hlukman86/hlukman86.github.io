import React from "react";

function SignUp () {
    return(
        <>
        <div>
            <h1>ini </h1>
        </div>
        </>
    )
}
export default SignUp