import  Home  from "../Page/Home"
import  ListMovie  from "../Page/ListMovie"
import  SignUp  from "./SignUp"
import  SignIn  from "./SignIn"
import MovieDetail from '../Page/MovieDetail'


export {
    Home,
    ListMovie,
    SignUp,
    SignIn,
    MovieDetail
}