// import axios from "axios"
// import React, {useState, useEffect} from "react"
// import Loading from "../Home/Loanding"

// function Schedule(props) {
//     // buat ambil data
//     // const id = props.id
//     // const [showSchedule, setShowSchedule] = useState({
//     //     loading: false,
//     //     result: {
//     //         data: []
//     //     }
//     // })

//     // useEffect(() => {
//     //     setShowSchedule(((prevState) => {
//     //         return{...prevState, loading: true}
//     //     }))
//     //     axios({
//     //         method: "GET",
//     //         url: `http://localhost:5000/api/v1/schedule/${id}`
//     //     }).then((res) => setShowSchedule({
//     //         loading: false,
//     //         result: res.data
//     //     })).catch()
//     // }, [])

//     return(
//         // buat nampilin data
//         // <div class="row">
//         //     <div class="container d-flex flex-wrap justify-content-center">
//         //         {showSchedule.loading ? <Loading/> : showSchedule.result.data.map((item) => (
//         //             <ScheduleCard  schedule={item} key="item.schedule_id"/>
//         //             )
//         //         )}
      
//         //     </div>
//         // </div>

//     )
// }

// function ScheduleCard(props) {
//     const schedule = props.schedule
//     // disini buat schedule card yang ada di movie detail
// }

// export default Schedule