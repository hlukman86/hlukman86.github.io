import Navbar from "../../Component/Navbar"

function ListMovie() {
    return(
        <>
            <Navbar />
            <main>
                <h1>List Movie</h1>
            </main>
        </>
        
    )
}

export default ListMovie