import { React, useEffect } from "react";
import Navbar from "../../Component/Navbar";
import NavbarLogOut from "../../Component/NavbarLogOut";
import Footer from "../../Component/Footer";
import "././Componet/homepage.css";
import Section1 from "./Componet/Section1";
import Section2 from "./Componet/Section2";
import Section3 from "./Componet/Section3";
import Section4 from "./Componet/Section4";
import { useDispatch, useSelector } from "react-redux";
import { GetMovie } from "../../redux/actions/Movie";
import {useNavigate} from "react-router-dom"
// import { AuthLogOut } from "../../redux/actions/Auth";


const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // movies 
  useEffect(() => {
    dispatch(GetMovie({ page: 1, limit: 10 }));
  },[]);
  
  const {data, error, loading } = useSelector((state) => state.movie);
  const {isSignIn} = useSelector((state) => state.auth);
  useEffect(()=> {
    if(isSignIn === false){// change == to ===
      navigate('/sign-in', {replace: true})
    }
},[isSignIn])
  console.log(data);

  return (
    <>
      {/* <Navbar /> */}
      {isSignIn ? (
      <Navbar/>
    ):(
     <NavbarLogOut/>
    )}
      <main>
        <Section1 />
        <Section2 />
        <Section3 />
        <Section4 />
      </main>
      <Footer />
    </>
  );
};

export default Home;
