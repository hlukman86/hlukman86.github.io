import {Link} from "react-router-dom"
import tickitz from "../img/Tickitz.svg"


function Navbar() {
    return(
        <>
        <nav className="navbar navbar-desktop navbar-expand-lg bg-white">
        <div className="container-fluid">
            <Link to="/">
                <a className="navbar-brand" >
                    <img src={tickitz} alt="logo-tickitz" />
                </a>
            </Link>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/">
                <a className="nav-link active bold" >Home</a>
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/list-movie">
                <a className="nav-link active bold" >List movie</a>
              </Link>
            </li>
            </ul>
          </div>
          <Link to="/Sign-In">
          <button className="btn btn-primary" type="submit">Log Out</button>
          </Link>
        </div>
      </nav>

      <nav className="navbar nav-phone navbar-expand-lg bg-white p-2">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            <img src={tickitz} alt="logo-tickitz" />
          </a>
          <div className="hamburger-button d-flex flex-column align-items-end" id="navbarNav">
            <div className="line mb-1">
            </div>
            <div className="line-2 mb-1">
            </div>
            <div className="line"></div>
          </div>
        </div>
      </nav>
        </>
        
        
        
    )
}

export default Navbar