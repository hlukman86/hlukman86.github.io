import {Link} from "react-router-dom"
import tickitz from "../img/Tickitz.svg"
import human from "../img/profile-pitcure-sm.png"



function NavbarLogin() {
    return(
        <>
        <nav classNameName="navbar navbar-desktop navbar-expand-lg bg-white">
        <div classNameName="container-fluid">
            <Link to="/">
                <a classNameName="navbar-brand" >
                    <img src={tickitz} alt="logo-tickitz" />
                </a>
            </Link>
          <div classNameName="collapse navbar-collapse" id="navbarNav">
            <ul classNameName="navbar-nav">
            <li classNameName="nav-item">
              <Link to="/">
                <a classNameName="nav-link active bold" >Home</a>
              </Link>
            </li>
            <li classNameName="nav-item">
              <Link to="/list-movie">
                <a classNameName="nav-link active bold" >List movie</a>
              </Link>
            </li>
            </ul>
          </div>
          <Link to="/">
          <img src = {human} alt='human'/>
          </Link>
        </div>
      </nav>

      <nav className="navbar nav-phone navbar-expand-lg bg-white p-2">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
            <img src={tickitz} alt="logo-tickitz" />
          </a>
          <div className="hamburger-button d-flex flex-column align-items-end" id="navbarNav">
            <div className="line mb-1">
            </div>
            <div className="line-2 mb-1">
            </div>
            <div className="line"></div>
          </div>
        </div>
      </nav>
        </>
        
        
        
    )
}

export default NavbarLogin